# COSC1078-BasicTemplate
COSC1078 - BasicTemplate for student use.
